I2C Sensors App
===============

Read data from the LSM303AGR accelerometer/magnetometer over I2C.

