LED Matrix App
==============

Display text on the 5 by 5 LED matrix.

Needs to strobe through LED rows at a quick rate in order to appear as though
all LEDs are active.

